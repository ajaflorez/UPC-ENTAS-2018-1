package pe.edu.upc.is20181;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Is20181Application {

	public static void main(String[] args) {
		SpringApplication.run(Is20181Application.class, args);
	}
}
